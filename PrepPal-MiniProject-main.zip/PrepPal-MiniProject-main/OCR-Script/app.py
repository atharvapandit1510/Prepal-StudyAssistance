# ---------------------------------------------------------
# app.py — Clean Minimal Version (Only Extraction + Timer)
# ---------------------------------------------------------

import os
import time
import tempfile
import requests
from flask import Flask, request, jsonify
from pdf_extractor import extract_pdf_text   # ✅ main extraction logic

# ---------------------------------------------------------
# Flask App Setup
# ---------------------------------------------------------
app = Flask(__name__)
print("🚀 Flask server starting...")


# ---------------------------------------------------------
# ROUTE: PDF Text Extraction
# ---------------------------------------------------------
@app.route("/ingest", methods=["POST"])
def ingest():
    start_time = time.time()
    data = request.get_json()
    file_url = data.get("file_url")

    if not file_url:
        return jsonify({"error": "No file_url provided"}), 400

    # ✅ Download the PDF temporarily
    tmp_fd, tmp_path = tempfile.mkstemp(suffix=".pdf")
    os.close(tmp_fd)

    try:
        print(f"📥 Downloading PDF from: {file_url}")
        r = requests.get(file_url, stream=True)
        with open(tmp_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)

        # ✅ Run the smart PDF extractor
        result = extract_pdf_text(tmp_path)

        print("\n" + "=" * 80)
        print(f"📘 Mode: {result.get('primary_mode', 'N/A')}")
        print(f"🔍 Scanned Detected: {result.get('detected_scanned', 'N/A')}")
        print(f"🧠 Notes: {result.get('notes', 'N/A')}")
        print("📄 Extracted Text Preview:")
        print(result.get("text", "")[:1500])
        print("=" * 80)

        # ✅ Timer
        elapsed = time.time() - start_time
        print(f"⏱️ Extraction completed in {elapsed:.2f} seconds\n")

        return jsonify({
            "raw_text": result.get("raw_text", ""),
            "cleaned_text": result.get("cleaned_text", ""),
            "text": result.get("postprocessed_text", ""),  # same as before
            "detected_scanned": result.get("detected_scanned", False),
            "primary_mode": result.get("primary_mode", "unknown"),
            "notes": result.get("notes", []),
            "time_taken": round(elapsed, 2)
        })


    finally:
        os.remove(tmp_path)


# ---------------------------------------------------------
# Run Flask App
# ---------------------------------------------------------
if __name__ == "__main__":
    print("🚀 Starting Flask app on port 9000...")
    app.run(port=9000, debug=True)
