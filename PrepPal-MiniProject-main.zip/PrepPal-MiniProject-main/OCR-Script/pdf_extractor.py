import fitz  # PyMuPDF
import pytesseract
from PIL import Image
import io, os, hashlib, json, re
from multiprocessing import Pool, cpu_count

# ✅ WINDOWS: Set Tesseract path if not in PATH
# pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

CACHE_DIR = "ocr_cache"
os.makedirs(CACHE_DIR, exist_ok=True)


# --- Utility: Compute file hash for caching ---
def _hash_file(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


# --- Cache helpers ---
def load_cache(path):
    key = _hash_file(path)
    cache_path = os.path.join(CACHE_DIR, f"{key}.json")
    if os.path.exists(cache_path):
        print(f"⚡ Using cached OCR result for {os.path.basename(path)}")
        with open(cache_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return None


def save_cache(path, result):
    key = _hash_file(path)
    cache_path = os.path.join(CACHE_DIR, f"{key}.json")
    with open(cache_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)


# --- OCR per page (runs in parallel) ---
def ocr_page(image_bytes):
    img = Image.open(io.BytesIO(image_bytes))
    config = r'--oem 1 --psm 3 -l eng'
    text = pytesseract.image_to_string(img, config=config)
    return text


# --- Main extraction function ---

def preprocess_text(text: str) -> str:
    """
    Clean OCR / extracted text for better LLM input.
    """
    if not text:
        return ""

    # Remove multiple spaces
    text = re.sub(r"[ \t]+", " ", text)

    # Remove multiple newlines
    text = re.sub(r"\n{2,}", "\n", text)

    # Fix hyphenated line breaks
    text = re.sub(r"-\s*\n\s*", "", text)

    # Remove random non-ASCII garbage except punctuation
    text = re.sub(r"[^\x00-\x7F\n.,;:?!()\-/% ]", "", text)

    # Normalize spacing around punctuation
    text = re.sub(r"\s*([.,;:?!])\s*", r"\1 ", text)

    # Collapse triple spaces
    text = re.sub(r"\s{3,}", " ", text)

    return text.strip()

# --- Main extraction function ---
def extract_pdf_text(file_path, max_pages=5, min_conf=90):

    cached = load_cache(file_path)
    if cached:
        return cached

    result = {
        "text": "",
        "detected_scanned": False,
        "primary_mode": "",
        "notes": [],
    }

    doc = fitz.open(file_path)

    # Detect text-based vs scanned
    for i, page in enumerate(doc):
        if i >= 3:
            break
        txt = page.get_text("text")
        if txt.strip():
            result["detected_scanned"] = False
            break
    else:
        result["detected_scanned"] = True

    # Text-based
    if not result["detected_scanned"]:
        print("🟢 Detected text-based PDF (PyMuPDF mode)")
        all_text = []
        for i, page in enumerate(doc):
            if max_pages and i >= max_pages:
                break
            all_text.append(page.get_text("text"))
        result["text"] = "\n".join(all_text)
        result["primary_mode"] = "pymupdf"
        result["notes"].append("Used PyMuPDF for extraction")

    # Scanned
    else:
        print("🟠 Detected scanned PDF (Tesseract mode)")
        images = []
        for i, page in enumerate(doc):
            if max_pages and i >= max_pages:
                break
            pix = page.get_pixmap(matrix=fitz.Matrix(1, 1))
            images.append(pix.tobytes("png"))

        with Pool(min(cpu_count(), len(images))) as p:
            texts = p.map(ocr_page, images)

        result["text"] = "\n".join(texts)
        result["primary_mode"] = "tesseract"
        result["notes"].append(f"OCR completed on {len(images)} pages (parallel mode)")

    doc.close()

    # Step 4 — Clean + consistent fields
    cleaned = re.sub(r'\s+', ' ', result.get("text", "")).strip()

    preprocessed = preprocess_text(result.get("text", ""))

    result["raw_text"] = result.get("text", "")
    result["postprocessed_text"] = cleaned
    result["cleaned_text"] = preprocessed

    if isinstance(result["notes"], list):
        result["notes"] = " | ".join(result["notes"])

    save_cache(file_path, result)
    return result



