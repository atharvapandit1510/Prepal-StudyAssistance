# OCR-Script/analyze_text.py
import sys
import os
import json
import io
from sklearn.feature_extraction.text import TfidfVectorizer
from rake_nltk import Rake
import nltk


sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# nltk.download('stopwords')
# nltk.download('punkt')
# nltk.download('punkt_tab')


def extract_keywords(text, num_keywords=20):
    # TF-IDF
    tfidf_vectorizer = TfidfVectorizer(stop_words="english", max_features=num_keywords)
    tfidf_matrix = tfidf_vectorizer.fit_transform([text])
    tfidf_scores = dict(zip(tfidf_vectorizer.get_feature_names_out(), tfidf_matrix.toarray()[0]))

    # RAKE
    rake = Rake()
    rake.extract_keywords_from_text(text)
    rake_scores = rake.get_ranked_phrases_with_scores()

    return tfidf_scores, rake_scores[:num_keywords]  # top 10


def main():
    if len(sys.argv) < 3:
        print("Usage: python analyze_text.py <question_text.txt> <syllabus_text.txt>", file=sys.stderr)
        sys.exit(1)

    question_path = sys.argv[1]
    syllabus_path = sys.argv[2]

    if not os.path.exists(question_path) or not os.path.exists(syllabus_path):
        print("One or both input files not found", file=sys.stderr)
        sys.exit(1)

    with open(question_path, 'r', encoding='utf-8') as f:
        question_text = f.read()

    with open(syllabus_path, 'r', encoding='utf-8') as f:
        syllabus_text = f.read()

    if not question_text.strip() or not syllabus_text.strip():
        print("One or both input files are empty", file=sys.stderr)
        sys.exit(1)

    # Extract keywords from question papers
    tfidf_scores, rake_scores = extract_keywords(question_text)

    # Split syllabus into lines
    topics = [line.strip() for line in syllabus_text.split('\n') if line.strip()]

    # Match keywords to syllabus topics
    topic_summary = {}
    keywords = [kw for _, kw in rake_scores]  # only keyword text

    for topic in topics:
        matched = [kw for kw in keywords if topic.lower() in kw.lower()]
        if matched:
            topic_summary[topic] = matched

    # Prepare final result
    result = {
        "tfidf": tfidf_scores,
        "rake": [{"keyword": k, "score": s} for s, k in rake_scores],
        "topic_summary": topic_summary
    }


    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

