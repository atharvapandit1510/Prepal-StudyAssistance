# import nltk

# # Optional: Set custom nltk_data path if needed
# # nltk.data.path.append("C:/Users/Atharva Pandit/AppData/Roaming/nltk_data")

# # Download required packages only once
# nltk.download('punkt')
# nltk.download('stopwords')
# nltk.download('punkt_tab')  # Fixes your current error

from nltk.corpus import stopwords
from nltk.tokenize import sent_tokenize

print("Stopwords sample:", stopwords.words("english")[:5])
print("Tokenized sentences:", sent_tokenize("This is a test. Here's another one."))
