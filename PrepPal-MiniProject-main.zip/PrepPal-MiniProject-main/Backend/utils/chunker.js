// utils/chunker.js
function chunkTextSentenceSafeWithOverlap(text, chunkSize = 800, overlap = 100) {
  if (!text || typeof text !== "string") return [];

  // split into sentences (keeps punctuation)
  const sentences = text.match(/[^\.!\?]+[\.!\?]+|\S+/g) || [];

  const chunks = [];
  let current = "";
  let charIndex = 0; // track position in original text
  let runningPos = 0; // where current chunk starts in chars

  for (const sentence of sentences) {
    const candidate = (current + " " + sentence).trim();
    if (candidate.length > chunkSize && current.trim().length > 0) {
      // push current chunk with offsets
      const start = runningPos;
      const end = runningPos + current.length;
      chunks.push({
        text: current.trim(),
        start,
        end,
        length: current.trim().length,
      });
      // prepare next chunk: include overlap from current tail
      const tail = current.slice(Math.max(0, current.length - overlap));
      runningPos = end - tail.length;
      current = tail;
    }
    current = (current + " " + sentence).trim();
  }

  if (current.trim().length > 0) {
    const start = runningPos;
    const end = runningPos + current.length;
    chunks.push({ text: current.trim(), start, end, length: current.trim().length });
  }

  return chunks;
}

module.exports = { chunkTextSentenceSafeWithOverlap };
