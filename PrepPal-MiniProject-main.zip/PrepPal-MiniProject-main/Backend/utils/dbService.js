const Document = require("../models/document.js");
const Question = require("../models/question.js");
const Topic = require("../models/topic.js");

/**
 * Save a new document to MongoDB
 * @param {Object} file - uploaded file info
 * @param {Object} textData - extracted text and meta from Flask
 * @param {Object} body - request body (year, subject)
 * @param {Array} chunks - precomputed chunks
 * @returns {Document} saved document
 */
async function saveDocument(file, textData, body, chunks,user) {
  const newDoc = await Document.create({
    originalName: file.originalname,
    cloudinaryUrl: file.path,
    cloudinaryId: file.filename,
    year: body.year,
    subject: body.subject,
    userId: user ? user._id : null,
    rawText: textData.raw_text,
    cleanedText: textData.cleaned_text,
    extractedText: textData.text,
    chunks: chunks.map((c) => ({
      text: c.text,
      start: c.start,
      end: c.end,
      length: c.length,
    })),
    meta: {
      detected_scanned: textData.detected_scanned,
      primary_mode: textData.primary_mode,
      notes: textData.notes,
      time_taken: textData.time_taken,
    },
  });

  return newDoc;
}

/**
 * Save an array of questions to MongoDB and link topics
 * @param {Array} questions - formatted questions
 * @returns {Array} saved questions
 */
async function saveQuestions(questions) {
  if (questions.length === 0) return [];

  // 1️⃣ Resolve topic names to IDs for each question
  for (const q of questions) {
    if (q.topics && Array.isArray(q.topics)) {
      const topicIds = [];
      for (const topicName of q.topics) {
        const topicDoc = await Topic.findOneAndUpdate(
          { name: topicName },
          { $setOnInsert: { name: topicName, questions: [] } }, // create if not exists
          { upsert: true, new: true }
        );
        topicIds.push(topicDoc._id);
      }
      q.topics = topicIds; // replace names with ObjectIds
    } else {
      q.topics = [];
    }
  }

  // 2️⃣ Insert questions into DB
  const inserted = await Question.insertMany(questions);

  // 3️⃣ Update Topic.documents with question references
  for (const q of inserted) {
    if (q.topics && q.topics.length > 0) {
      await Topic.updateMany(
        { _id: { $in: q.topics } },
        { $addToSet: { questions: q._id } }
      );
    }
  }

  return inserted;
}


module.exports = { saveDocument, saveQuestions };
