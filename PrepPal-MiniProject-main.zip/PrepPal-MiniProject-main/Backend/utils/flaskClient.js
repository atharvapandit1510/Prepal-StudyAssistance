// utils/flaskClient.js
const axios = require("axios");

/**
 * Send a file URL + mimetype to the Flask extraction server
 * Returns: { raw_text, cleaned_text, text, ... }
 */
async function extractTextFromFlask(fileUrl, mimeType) {
  try {
    const response = await axios.post(
      "http://127.0.0.1:9000/ingest",
      {
        file_url: fileUrl,
        mimetype: mimeType,
      },
      {
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
      }
    );

    return response.data;
  } catch (err) {
    console.error("❌ Flask extraction error:", err.message);
    throw new Error("Flask text extraction failed");
  }
}

module.exports = { extractTextFromFlask };
