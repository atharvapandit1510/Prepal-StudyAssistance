require("dotenv").config();
const { GoogleGenAI } = require("@google/genai");

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
});

async function generateQuestionsFromChunk(chunkText) {
  try {
    const prompt = `
You are an exam-question extractor AI.

From the following text, extract ONLY actual exam questions.
Ignore filler text, headers, dates, marks table, course outcomes, or nonsense.

For each question, also provide the relevant topic(s) from the text.

Output STRICT JSON ONLY:

{
  "questions": [
    { 
      "label": "Q1", 
      "text": "question text", 
      "marks": 5,
      "topics": ["topic1", "topic2"]
    }
  ]
}

Rules:
- "text" must contain a complete question sentence.
- "topics" should be an array of 1-3 main topics the question belongs to.
- Remove numbering artifacts (1), Q.1, a), i), etc.
- Do NOT hallucinate missing questions.
- If no clear question is found, return {"questions": []}

TEXT:
${chunkText}
`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });

    // -----------------------------
    // FIX: Correct Gemini output
    // -----------------------------
    let text = "";

    if (
      response.candidates &&
      response.candidates[0] &&
      response.candidates[0].content &&
      response.candidates[0].content.parts &&
      response.candidates[0].content.parts[0].text
    ) {
      text = response.candidates[0].content.parts[0].text;
    } else {
      console.log(
        "⚠️ Unexpected response format:",
        JSON.stringify(response, null, 2)
      );
      return { questions: [] };
    }

    text = text
      .replace(/```json/i, "")
      .replace(/```/g, "")
      .trim();

    // -----------------------------
    // Try parsing JSON output
    // -----------------------------
    try {
      const parsed = JSON.parse(text);

      // Ensure consistent return format:
      if (!parsed.questions || !Array.isArray(parsed.questions)) {
        return { questions: [] };
      }

      return { questions: parsed.questions };
    } catch (err) {
      console.log("⚠️ Gemini returned non-JSON text:");
      console.log(text);
      return { questions: [] };
    }
  } catch (err) {
    console.error("❌ Gemini Error:", err);
    return { questions: [] };
  }
}

module.exports = {
  generateQuestionsFromChunk,
};
