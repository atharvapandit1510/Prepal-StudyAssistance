// utils/geminiService.js
const { generateQuestionsFromChunk } = require("./geminiClient.js");

/**
 * Process a single chunk with Gemini
 * @param {string} chunkText
 * @param {number} chunkIndex
 * @param {string} docId
 * @returns {Array} formatted questions
 */
async function processChunk(chunkText, chunkIndex, docId) {
  console.log(`\n🧠 Gemini processing chunk ${chunkIndex + 1}...`);

  const result = await generateQuestionsFromChunk(chunkText);

  const questions = Array.isArray(result?.questions) ? result.questions : [];

  return questions.map((q, index) => {
    const questionObj = {
      documentId: docId,
      chunkIndex,
      label: q.label || `Q${chunkIndex + 1}-${index + 1}`,
      text: q.text,
      marks: q.marks ?? null,
      topics: q.topics || [], // new field
      meta: q.meta || {},
    };

    // ✅ Log topics for verification
    console.log(
      `Chunk ${chunkIndex + 1} - Q${index + 1} topics:`,
      questionObj.topics
    );

    return questionObj;
  });
}

/**
 * Process chunks in batches (avoids free-tier rate limits)
 * @param {Array} chunks
 * @param {number} batchSize
 * @param {string} docId
 * @param {number} cooldownMs - delay between batches in ms
 * @returns {Array} all formatted questions
 */
async function runInBatches(chunks, batchSize = 2, docId, cooldownMs = 5000) {
  const allQuestions = [];

  for (let i = 0; i < chunks.length; i += batchSize) {
    const batch = chunks.slice(i, i + batchSize);

    console.log(`\n🔷 Running batch ${i / batchSize + 1}...`);

    const results = await Promise.all(
      batch.map((chunk, idx) => processChunk(chunk.text, i + idx, docId))
    );

    results.forEach((r) => allQuestions.push(...r));

    // Free-tier safe cooldown
    await new Promise((r) => setTimeout(r, cooldownMs));
  }

  return allQuestions;
}

module.exports = { processChunk, runInBatches };
