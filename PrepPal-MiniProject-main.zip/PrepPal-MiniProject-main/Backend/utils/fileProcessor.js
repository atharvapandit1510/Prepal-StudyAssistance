const { extractTextFromFlask } = require("./flaskClient");
const { createChunks } = require("./chunkService");
const { saveDocument, saveQuestions } = require("./dbService");
const { runInBatches } = require("./geminiService");
const Question = require("../models/question");


async function processFile(file, reqBody,user) {
  const cloudUrl = file.path;
  const cloudId = file.filename;

  // 1) Extract text via Flask
  const data = await extractTextFromFlask(cloudUrl, file.mimetype);

  // 2) Chunk the cleaned text
  const chunks = createChunks(data.cleaned_text);

  // 3) Save document
  const newDoc = await saveDocument(file, data, reqBody, chunks,user);

  // 4) Run Gemini batch processing
  const allQuestions = await runInBatches(chunks, 2, newDoc._id);

  // 5) Save questions
  // 5) Save questions and get the saved docs
  let savedQuestions = [];
  if (allQuestions.length > 0) {
    savedQuestions = await saveQuestions(allQuestions);
    // Populate topics
    savedQuestions = await Question.find({
      _id: { $in: savedQuestions.map((q) => q._id) },
    }).populate("topics");
  }

  // Return structured result for rendering
  return {
    document: newDoc.toObject(),
    chunks,
    questions: savedQuestions.map((q) => q.toObject()),
    topics: savedQuestions.flatMap((q) => q.topics.map((t) => t.name)), // trending topics
  };
}

module.exports = { processFile };
