// utils/chunkService.js
const { chunkTextSentenceSafeWithOverlap } = require("./chunker.js");

/**
 * Safely chunk cleaned text for Gemini processing.
 * 
 * @param {string} text - Cleaned text from Flask
 * @param {number} chunkSize - Default 800
 * @param {number} overlap - Default 100
 * @returns {Array} Array of chunks [{ text, start, end, length }]
 */
function createChunks(text, chunkSize = 800, overlap = 100) {
  if (!text || text.length === 0) return [];
  return chunkTextSentenceSafeWithOverlap(text, chunkSize, overlap);
}

module.exports = { createChunks };
