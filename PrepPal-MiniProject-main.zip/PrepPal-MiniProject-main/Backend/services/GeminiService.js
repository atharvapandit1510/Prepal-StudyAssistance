// services/GeminiService.js
const { GoogleGenerativeAI } = require("@google/generative-ai");
require("dotenv").config();

if (!process.env.GEMINI_API_KEY) {
  console.error("❌ ERROR: Gemini API Key missing in .env file");
}

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });

/** ✅ Clean formatter removes markdown mess */
function cleanResponse(text) {
  return text
    .replace(/[*_`~#>-]/g, "")          // remove markdown symbols
    .replace(/\n{3,}/g, "\n\n")         // remove extra blank lines
    .trim();
}

/** ✅ Single question call */
async function askGemini(prompt) {
  try {
    const result = await model.generateContent(prompt);
    const text = result.response.text();
    return cleanResponse(text);
  } catch (err) {
    console.error("❌ Gemini askGemini Error:", err);
    return "⚠️ Gemini API Error — check console or API key.";
  }
}

/** ✅ Conversation mode using history */
async function continueChat(history, userMessage) {
  try {
    const chat = model.startChat({ history });
    const result = await chat.sendMessage(userMessage);
    const text = result.response.text();
    return cleanResponse(text);
  } catch (err) {
    console.error("❌ Gemini continueChat Error:", err);
    return "⚠️ Gemini API Error while continuing chat.";
  }
}

module.exports = { askGemini, continueChat };
