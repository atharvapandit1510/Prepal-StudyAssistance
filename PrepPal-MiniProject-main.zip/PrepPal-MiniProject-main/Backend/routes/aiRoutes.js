// Backend/routes/aiRoutes.js
const express = require("express");
const router = express.Router();
const { askGemini } = require("../services/GeminiService");

// 👉 GET route to render Ask AI page
router.get("/ask-ai", (req, res) => {
  res.render("ask-ai", {
    aiAnswer: null,
    error: null,
    text: null,
    questions: null,
    keywords: null
  });
});

// POST - Ask AI a question
router.post("/ask-ai", async (req, res) => {
  const question = req.body.question;

  try {
    const aiAnswerRaw = await askGemini(question);

    // ✅ Clean and format the output
    let aiAnswer = aiAnswerRaw
      .replace(/\n{2,}/g, "<br><br>")   // multiple newlines -> paragraph breaks
      .replace(/\n/g, "<br>")           // single newline -> line break
      .trim();

    res.render("ask-ai.ejs", {
      text: null,
      questions: null,
      aiAnswer, // formatted answer
      keywords: null,
      error: null
    });
  } catch (err) {
    console.error("AI Error:", err);
    res.render("ask-ai.ejs", {
      text: null,
      questions: null,
      aiAnswer: null,
      keywords: null,
      error: "⚠️ Failed to contact AI assistant."
    });
  }
});

module.exports = router;
