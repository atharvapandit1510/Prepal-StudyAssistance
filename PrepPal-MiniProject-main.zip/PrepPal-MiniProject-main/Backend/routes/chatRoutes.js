const express = require("express");
const router = express.Router();
const { askGemini, continueChat } = require("../services/GeminiService");
const Chat = require("../models/chat");
const Message = require("../models/message");

// Middleware to check if user is logged in
function isLoggedIn(req, res, next) {
    if (req.isAuthenticated()) {
        return next();
    }
    req.flash("error", "You must be logged in to access this page.");
    res.redirect("/login");
}

// GET /chat - Renders the main chat page (new chat)
router.get("/chat", isLoggedIn, async (req, res) => {
    try {
        const chats = await Chat.find({ userId: req.user._id }).sort({ createdAt: -1 });
        res.render("chat.ejs", {
            chats: chats,
            activeChat: null,
            messages: [],
            error: null
        });
    } catch (err) {
        req.flash("error", "Could not load chat history.");
        res.redirect("/upload");
    }
});

// GET /chat/:id - Renders an existing chat
router.get("/chat/:id", isLoggedIn, async (req, res) => {
    try {
        const chatId = req.params.id;
        const activeChat = await Chat.findOne({ _id: chatId, userId: req.user._id });
        if (!activeChat) {
            req.flash("error", "Chat not found or you do not have permission.");
            return res.redirect("/chat");
        }
        const chats = await Chat.find({ userId: req.user._id }).sort({ createdAt: -1 });
        const messages = await Message.find({ chatId: chatId }).sort({ createdAt: 1 });
        res.render("chat.ejs", {
            chats: chats,
            activeChat: activeChat,
            messages: messages,
            error: null
        });
    } catch (err) {
        req.flash("error", "Could not load chat.");
        res.redirect("/chat");
    }
});

// ⭐ --- UPDATED POST ROUTE --- ⭐
// This route now handles a JSON request and sends a JSON response.
router.post("/chat", isLoggedIn, async (req, res) => {
    // We are now receiving JSON, so req.body will have { question, chatId }
    const { question, chatId } = req.body;
    let currentChatId = chatId;

    try {
        // --- Case 1: NEW CHAT ---
        if (chatId === 'new') {
            const aiAnswer = await askGemini(question);

            const newChat = new Chat({
                userId: req.user._id,
                title: question.substring(0, 40) + "..."
            });
            await newChat.save();
            currentChatId = newChat._id;

            const userMessage = await Message.create({
                chatId: currentChatId,
                role: "user",
                content: question
            });

            const modelMessage = await Message.create({
                chatId: currentChatId,
                role: "model",
                content: aiAnswer
            });
            
            // ⭐ Send JSON response instead of redirecting
            res.json({
                userMessage,
                modelMessage,
                newChatId: currentChatId // Send the new ID to the client
            });

        // --- Case 2: EXISTING CHAT ---
        } else {
            const chatToUpdate = await Chat.findOne({ _id: currentChatId, userId: req.user._id });
            if (!chatToUpdate) {
                return res.status(403).json({ error: "You do not have permission to access this chat." });
            }

            const historyMessages = await Message.find({ chatId: currentChatId }).sort({ createdAt: 1 });
            const formattedHistory = historyMessages.map(msg => ({
                role: msg.role,
                parts: [{ text: msg.content }]
            }));
            
            const aiAnswer = await continueChat(formattedHistory, question);

            const userMessage = await Message.create({
                chatId: currentChatId,
                role: "user",
                content: question
            });

            const modelMessage = await Message.create({
                chatId: currentChatId,
                role: "model",
                content: aiAnswer
            });

            // ⭐ Send JSON response instead of redirecting
            res.json({
                userMessage,
                modelMessage,
                newChatId: currentChatId // Send the existing ID
            });
        }
    } catch (err) {
        console.error("Chat POST Error:", err);
        // ⭐ Send a JSON error response
        res.status(500).json({ error: "Failed to get AI response." });
    }
});

module.exports = router;