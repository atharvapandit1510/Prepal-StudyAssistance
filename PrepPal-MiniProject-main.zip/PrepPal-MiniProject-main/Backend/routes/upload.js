// ---------------------------------------------------------
// upload.js — Upload + Text Extraction + Memory Logging + Gemini
// ---------------------------------------------------------
const express = require("express");
const router = express.Router();
const multer = require("multer");
const { cloudinary, storage } = require("../cloudConfig.js");
const upload = multer({ storage });

const { processFile } = require("../utils/fileProcessor.js");

// ---------------------------------------------------------
// GET Upload Page
// ---------------------------------------------------------
router.get("/upload", (req, res) => {
  res.render("index.ejs", { text: null, error: null });
});

// ---------------------------------------------------------
// POST Upload and Extract Text + Generate Questions
// ---------------------------------------------------------
router.post("/upload", upload.array("files", 20), async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ error: "No files uploaded" });
    }

    const results = [];

    for (const file of req.files) {
      // Process each file via modular function
      const result = await processFile(file, req.body,req.user);
      results.push(result);
    }

    res.render("index.ejs", { text: results, error: null });
  } catch (err) {
    console.error("Upload or Extraction Error:", err);
    res.render("index.ejs", { text: null, error: "Upload or extraction failed" });
  }
});

module.exports = router;
