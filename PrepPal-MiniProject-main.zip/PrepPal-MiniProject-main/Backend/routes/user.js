const express = require("express");
const router = express.Router();
const passport = require("passport");
const mongoose = require("mongoose");

const User = require("../models/user.js");
const Document = require("../models/document.js");
const Question = require("../models/question.js");

// Middleware to check if user is logged in
function isLoggedIn(req, res, next) {
    if (req.isAuthenticated()) {
        return next();
    }
    req.flash("error", "You must be logged in to access this page.");
    res.redirect("/login");
}

// GET signup page
router.get("/signup", (req, res) => {
    res.render("users/signup.ejs", { error: null ,emailError: null });
});

// POST signup
router.post("/signup", async (req, res, next) => {
    try {
        const { email, username, password, terms } = req.body;

        // Check terms checkbox
        if (!terms) {
            return res.render("users/signup.ejs", { error: "You must agree to the terms and conditions." , emailError: null });
        }

        if (!/^[a-zA-Z0-9._%+-]+@gmail\.com$/.test(email)) {
  return res.render("users/signup.ejs", { error: null, emailError: "Please enter a valid gmail address." });
}


        const newUser = new User({ email, username });
        
        const registeredUser = await User.register(newUser, password);

        req.login(registeredUser, (err) => {
            if (err) {
                return next(err);
            }
            req.flash("success", "Welcome to PrepPal!");
            let redirectUrl = res.locals.redirectUrl || "/upload";
            res.redirect(redirectUrl);
        });
    } catch (e) {
        
        res.render("users/signup.ejs", { error: e.message });
    }
});

// GET login page
router.get("/login", (req, res) => {
    res.render("users/login.ejs", { error: null });
});

// POST login
router.post("/login", 
    passport.authenticate("local", {
        failureFlash: true,
        failureRedirect: "/login",
    }),
    (req, res) => {
        req.flash("success", `Welcome back, ${req.user.username}!`);
        let redirectUrl = res.locals.redirectUrl || "/upload";
        delete res.locals.redirectUrl;
        res.redirect(redirectUrl);
    }
);

// GET profile page
router.get("/profile", isLoggedIn, async (req, res) => {
    try {
        const userId = req.user._id;
        
        // Get user's document count
        const documentCount = await Document.countDocuments({ 
            $or: [
                { userId: userId },
                { uploadedBy: userId }
            ]
        });
        
        // Get user's total questions extracted
        const userDocuments = await Document.find({ 
            $or: [
                { userId: userId },
                { uploadedBy: userId }
            ]
        });
        
        let questionCount = 0;
        for (const doc of userDocuments) {
            const count = await Question.countDocuments({ documentId: doc._id });
            questionCount += count;
        }
        
        // Calculate days since joined
        const daysSinceJoined = Math.floor(
            (new Date() - new Date(req.user.createdAt || Date.now())) / (1000 * 60 * 60 * 24)
        );

        res.render("users/profile.ejs", {
            user: req.user,
            documentCount,
            questionCount,
            daysSinceJoined
        });
    } catch (error) {
        console.error("Profile Error:", error);
        req.flash("error", "Unable to load profile information.");
        res.redirect("/upload");
    }
});

// GET history page
router.get("/history", isLoggedIn, async (req, res) => {
    try {
        const userId = req.user._id;
        
        // Get all documents uploaded by this user with question counts
        const documents = await Document.aggregate([
            {
                $match: {
                    $or: [
                        { userId: userId },
                        { uploadedBy: userId }
                    ]
                }
            },
            {
                $lookup: {
                    from: "questions",
                    localField: "_id",
                    foreignField: "documentId",
                    as: "questions"
                }
            },
            {
                $addFields: {
                    questionCount: { $size: "$questions" },
                    topicCount: { $size: { $ifNull: ["$topics", []] } }
                }
            },
            {
                $sort: { uploadedAt: -1 }
            }
        ]);

        // Calculate statistics
        const totalQuestions = documents.reduce((sum, doc) => sum + doc.questionCount, 0);
        
        // Get unique subjects and years
        const uniqueSubjects = [...new Set(documents
            .map(doc => doc.subject)
            .filter(subject => subject && subject.trim() !== '')
        )];
        
        const uniqueYears = [...new Set(documents
            .map(doc => doc.year)
            .filter(year => year)
        )].sort((a, b) => b - a);

        // Count recent uploads (this month)
        const thisMonth = new Date();
        thisMonth.setDate(1);
        thisMonth.setHours(0, 0, 0, 0);
        
        const recentUploads = documents.filter(doc => 
            new Date(doc.uploadedAt) >= thisMonth
        ).length;

        res.render("users/history.ejs", {
            documents,
            totalQuestions,
            uniqueSubjects,
            uniqueYears,
            recentUploads
        });
    } catch (error) {
        console.error("History Error:", error);
        req.flash("error", "Unable to load upload history.");
        res.redirect("/upload");
    }
});

// DELETE document route
router.post("/delete-document/:id", isLoggedIn, async (req, res) => {
    try {
        const documentId = req.params.id;
        const userId = req.user._id;
        
        // Find document and verify ownership
        const document = await Document.findOne({
            _id: documentId,
            $or: [
                { userId: userId },
                { uploadedBy: userId }
            ]
        });

        if (!document) {
            req.flash("error", "Document not found or you don't have permission to delete it.");
            return res.redirect("/history");
        }

        // Delete associated questions
        await Question.deleteMany({ documentId: documentId });
        
        // Delete the document
        await Document.findByIdAndDelete(documentId);
        
        // Optional: Delete from Cloudinary
        // const { cloudinary } = require("../cloudConfig.js");
        // await cloudinary.uploader.destroy(document.cloudinaryId);

        req.flash("success", "Document deleted successfully.");
        res.redirect("/history");
    } catch (error) {
        console.error("Delete Error:", error);
        req.flash("error", "Unable to delete document.");
        res.redirect("/history");
    }
});

// GET document details route
// GET document details route
router.get("/document-details/:id", isLoggedIn, async (req, res) => {
    try {
        const documentId = req.params.id;
        const userId = req.user._id;

        // Find document and verify ownership
        const document = await Document.findOne({
            _id: documentId,
            $or: [
                { userId: userId },
                { uploadedBy: userId }
            ]
        });

        if (!document) {
            req.flash("error", "Document not found or you don't have permission to view it.");
            return res.redirect("/history");
        }

        // Get associated questions
        const questions = await Question.find({ documentId: documentId });

        res.render("users/document-details.ejs", {
            document,
            questions
        });
    } catch (err) {
        console.error("Error fetching document details:", err);
        req.flash("error", "Something went wrong while retrieving the document.");
        res.redirect("/history");
    }
});

// POST logout route
router.post("/logout", (req, res, next) => {
  req.logout(function(err) {
    if (err) { return next(err); }
    req.flash("success", "You have logged out successfully.");
    res.redirect("/login");
  });
});


module.exports = router;