const cloudinary = require('cloudinary').v2;
const {CloudinaryStorage} = require('multer-storage-cloudinary');

cloudinary.config({
    cloud_name: process.env.CLOUD_NAME,
    api_key:process.env.CLOUD_API_KEY,
    api_secret:process.env.CLOUD_SECRET_KEY
});

const storage = new CloudinaryStorage({
  cloudinary,
  params: async (req, file) => {
    // 👇 Force correct resource type depending on file mimetype
    let resourceType = "auto";
    if (
      file.mimetype === "application/pdf" ||
      file.mimetype ===
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||
      file.mimetype === "text/plain"
    ) {
      resourceType = "raw";
    }

    return {
      folder: "prepPalFiles",
      resource_type: resourceType, // ✅ ensures PDF/DOCX/TXT work
      allowed_formats: ["pdf", "docx", "txt", "png", "jpg", "jpeg"],
    };
  },
});

module.exports = {
    cloudinary,
    storage
}