// ✅ Load environment variables
if (process.env.NODE_ENV !== "production") {
  require("dotenv").config();
}

// 🔹 Basic Imports
const express = require("express");
const multer = require("multer");
const path = require("path");
const mongoose = require("mongoose");
const fs = require("fs");
const { spawn } = require("child_process");
const ejsMate = require("ejs-mate");

// 🔹 Auth & Session
const passport = require("passport");
const localStrategy = require("passport-local");
const session = require("express-session");
const flash = require("connect-flash");

// 🔹 Mongo Models (Only one of each)
const Document = require("./models/document.js");
const Question = require("./models/question.js");
const Topic = require("./models/topic.js");
const User = require("./models/user.js");
const Chat = require("./models/chat.js");
const Message = require("./models/message.js");

// 🔹 Routes (Only one of each)
const userRouter = require("./routes/user.js");
const uploadRouter = require("./routes/upload.js");
const aiRoutes = require("./routes/aiRoutes");
const chatRouter = require("./routes/chatRoutes.js");

// 🔹 Database connection
// (ONLY ONE connection block, connecting to the correct DB)
main()
  .then(() => console.log("✅ Connected to MongoDB"))
  .catch((err) => console.error("❌ Mongo Error:", err));

async function main() {
  // Use the correct database name (capital 'P')
  await mongoose.connect("mongodb://127.0.0.1:27017/PrepPal");
}

// 🔹 Express app
const app = express();
const port = 8080;

// 🔹 Middlewares
// (ONLY ONE set of these)
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// View engine (ONLY ONE set of these)
app.engine("ejs", ejsMate);
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.static(path.join(__dirname, "public")));

// Sessions & Flash
app.use(
  session({
    secret: "someSecretKey",
    resave: false,
    saveUninitialized: true,
  })
);
app.use(flash());

// Passport Auth
app.use(passport.initialize());
app.use(passport.session());
passport.use(new localStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

// Flash + Current User in Views
app.use((req, res, next) => {
  res.locals.success = req.flash("success");
  res.locals.error = req.flash("error");
  res.locals.currentUser = req.user;
  next();
});

// File uploads (Multer)
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname)),
});
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });

// ✅ Routes
// (ONLY ONE set of these)
app.use("/", userRouter);
app.use("/", uploadRouter);
app.use("/", aiRoutes);
app.use("/", chatRouter);

// Root route
app.get("/", (req, res) => {
  res.send("✅ Server is listening!");
});

// Error handler
app.use((err, req, res, next) => {
  console.error("❌ Error:", err);
  req.flash("error", err.message);
  res.redirect("/upload");
});

// Start server
app.listen(port, () => {
  console.log(`🚀 Server running at http://localhost:${port}`);
});