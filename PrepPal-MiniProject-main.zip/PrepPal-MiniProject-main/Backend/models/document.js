const mongoose = require('mongoose');

const DocumentSchema = new mongoose.Schema({

    originalName: {
        type: String,
        required: true,
    },

    cloudinaryUrl: {
        type: String,
        required: true
    },

    cloudinaryId: {
        type: String,
        required: true
    },

    year: Number,
    subject: String,

    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    },

    // ⭐ NEW FIELDS REQUIRED FOR EXTRACTION
    rawText: String,          // Direct extracted text
    cleanedText: String,      // Preprocessed clean version
    extractedText: String,    // Final text used for processing (same as cleanedText)

    // ⭐ Minimal meta object
    meta: {
        detected_scanned: Boolean,
        primary_mode: String,
        notes: String,
        time_taken: Number
    }

}, { timestamps: true });

module.exports = mongoose.model("Document", DocumentSchema);
