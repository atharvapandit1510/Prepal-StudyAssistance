const mongoose = require("mongoose");


const QuestionSchema = new mongoose.Schema({
  documentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Document",
    required: true,
  },
  chunkIndex: Number,
  label: String,
  text: { type: String, required: true },
  marks: Number,
  bloomsLevel: String,
  meta: {},
  topics: [
    { type: mongoose.Schema.Types.ObjectId, ref: "Topic" } // <-- reference only
  ],
}, { timestamps: true });



module.exports = mongoose.model("Question", QuestionSchema);
