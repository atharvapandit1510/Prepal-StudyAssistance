const mongoose = require('mongoose');
const passportLocalMongoose = require('passport-local-mongoose');

const UserSchema = new mongoose.Schema({
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        trim: true,
        match : [/\S+@\S+\.\S+/, 'Invalid email format']
    },
     documentId : [{
            type : mongoose.Schema.Types.ObjectId,
            ref : "Document"
        }]
},{timestamps:true});

// const UserSchema = new Schema({
//   email: {
//     type: String,
//     required: true,
//     validate: {
//       validator: function (value) {
//         // Regex: must end with @gmail.com
//         return /^[a-zA-Z0-9._%+-]+@gmail\.com$/.test(value);
//       },
//       message: 'Invalid Gmail address. Must be of the form -----@gmail.com'
//     }
//   },
//   documentId: {
//     type: mongoose.Schema.Types.ObjectId,
//     ref: "Document"
//   }
// });


UserSchema.plugin(passportLocalMongoose);

module.exports = mongoose.model('User', UserSchema);