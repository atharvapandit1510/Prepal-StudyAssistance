document.addEventListener('DOMContentLoaded', function() {
    // === Profile dropdown functionality ===
    const profileButton = document.getElementById('profileButton');
    const profileMenu = document.getElementById('profileMenu');

    if (profileButton && profileMenu) {
        profileButton.addEventListener('click', function(e) {
            e.stopPropagation();
            profileButton.classList.toggle('active');
            profileMenu.classList.toggle('show');
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!profileButton.contains(e.target) && !profileMenu.contains(e.target)) {
                profileButton.classList.remove('active');
                profileMenu.classList.remove('show');
            }
        });

        // Close dropdown on escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                profileButton.classList.remove('active');
                profileMenu.classList.remove('show');
            }
        });
    }

    // === Tab functionality ===
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');

    if (tabButtons.length > 0) {
        tabButtons.forEach(button => {
            button.addEventListener('click', () => {
                
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));
                
                button.classList.add('active');
                const tabName = button.getAttribute('data-tab');
                const targetContent = document.getElementById(tabName);
                if (targetContent) {
                    targetContent.classList.add('active');
                }
            });
        });
    }

    // === File upload handling ===
    const uploadForm = document.getElementById('uploadForm');
    const fileInput = document.getElementById('fileInput');
    const uploadZone = document.querySelector('.upload-zone');

    if (uploadForm && fileInput && uploadZone) {
        uploadForm.addEventListener('submit', function() {
            const loadingSection = document.getElementById('loadingSection');
            if (loadingSection) {
                loadingSection.style.display = 'block';
                loadingSection.classList.add('show');
            }
        });

        uploadZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadZone.style.backgroundColor = 'var(--bg-tertiary)';
            uploadZone.style.border = '2px dashed var(--primary-color)';
        });

        uploadZone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            uploadZone.style.backgroundColor = 'transparent';
            uploadZone.style.border = 'none';
        });

        uploadZone.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadZone.style.backgroundColor = 'transparent';
            uploadZone.style.border = 'none';
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                const dt = new DataTransfer();
                for (let file of files) {
                    dt.items.add(file);
                }
                fileInput.files = dt.files;
                
                showFileCount(files.length);
            }
        });

        fileInput.addEventListener('change', function() {
            const files = this.files;
            if (files.length > 0) {
                showFileCount(files.length);
            }
        });
    }

    // === Initialize animations and effects ===
    // Smooth scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Hover effects on buttons
    document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-1px)';
        });
        btn.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    // Hover effects on cards, topic-item, stat-item
    document.querySelectorAll('.card, .topic-item, .stat-item').forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';

        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
        });
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    // Animate elements on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    document.querySelectorAll('.card, .topic-item, .stat-item').forEach(el => {
        observer.observe(el);
    });

    // === Add copy buttons to readonly textareas ===
    const textareas = document.querySelectorAll('textarea[readonly]');
    textareas.forEach(textarea => {
        const wrapper = document.createElement('div');
        wrapper.style.position = 'relative';
        textarea.parentNode.insertBefore(wrapper, textarea);
        wrapper.appendChild(textarea);
        
        const copyBtn = document.createElement('button');
        copyBtn.innerHTML = '<i class="fas fa-copy"></i> Copy';
        copyBtn.className = 'btn btn-primary';
        copyBtn.style.cssText = `
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 0.5rem 1rem;
            font-size: 0.8rem;
            z-index: 10;
        `;
        
        copyBtn.addEventListener('click', () => {
            copyToClipboard(textarea.value, copyBtn);
        });
        
        wrapper.appendChild(copyBtn);
    });

    // === Enhanced form submission with progress ===
    if (uploadForm) {
        uploadForm.addEventListener('submit', function(e) {
            const files = fileInput.files;
            
            if (files.length === 0) {
                e.preventDefault();
                showError('Please select at least one file to upload.');
                return;
            }
            
            if (!validateFiles(files)) {
                e.preventDefault();
                return;
            }
            
            const { progressDiv, progressBar } = createProgressBar();
            animateProgress(progressBar, 5000);
            
            showSuccess(`Uploading ${files.length} file${files.length > 1 ? 's' : ''}...`);
        });
    }

    // === Add tooltips ===
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    tooltipElements.forEach(el => {
        el.addEventListener('mouseenter', function() {
            const tooltip = document.createElement('div');
            tooltip.className = 'tooltip';
            tooltip.textContent = this.getAttribute('data-tooltip');
            tooltip.style.cssText = `
                position: absolute;
                background: var(--text-primary);
                color: white;
                padding: 0.5rem 0.75rem;
                border-radius: 4px;
                font-size: 0.8rem;
                white-space: nowrap;
                z-index: 1000;
                pointer-events: none;
            `;
            document.body.appendChild(tooltip);
            
            const rect = this.getBoundingClientRect();
            tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
            tooltip.style.top = rect.top - tooltip.offsetHeight - 8 + 'px';
        });
        
        el.addEventListener('mouseleave', function() {
            const tooltip = document.querySelector('.tooltip');
            if (tooltip) {
                tooltip.remove();
            }
        });
    });
});

// === Logout confirmation functions ===
function confirmLogout() {
    document.getElementById('logoutModal').style.display = 'flex';
}

function closeLogoutModal() {
    document.getElementById('logoutModal').style.display = 'none';
}

// === Other utility functions used above ===
function showFileCount(count) {
    const uploadText = document.querySelector('.upload-text');
    const uploadSubtext = document.querySelector('.upload-subtext');
    
    if (uploadText && uploadSubtext) {
        uploadText.textContent = `${count} file${count > 1 ? 's' : ''} selected`;
        uploadSubtext.innerHTML = `Ready to analyze your documents<br>Click "Analyze Documents" to proceed`;
        
        const uploadZone = document.querySelector('.upload-zone');
        if (uploadZone) {
            uploadZone.style.backgroundColor = 'var(--bg-tertiary)';
            uploadZone.style.border = '2px solid var(--success-color)';
        }
    }
}

function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.innerHTML = `
        <i class="fas fa-exclamation-triangle"></i>
        <span>${message}</span>
    `;
    
    const mainContainer = document.querySelector('.main-container');
    if (mainContainer) {
        mainContainer.insertBefore(errorDiv, mainContainer.firstChild);
        
        setTimeout(() => {
            if (errorDiv.parentNode) {
                errorDiv.parentNode.removeChild(errorDiv);
            }
        }, 5000);
    }
}

function showSuccess(message) {
    const successDiv = document.createElement('div');
    successDiv.className = 'success-message';
    successDiv.style.cssText = `
        background: #f0fdf4;
        color: var(--success-color);
        padding: 1rem;
        border-radius: 8px;
        border: 1px solid #bbf7d0;
        margin-bottom: 1rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    `;
    successDiv.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <span>${message}</span>
    `;
    
    const mainContainer = document.querySelector('.main-container');
    if (mainContainer) {
        mainContainer.insertBefore(successDiv, mainContainer.firstChild);
        
        setTimeout(() => {
            if (successDiv.parentNode) {
                successDiv.parentNode.removeChild(successDiv);
            }
        }, 3000);
    }
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function validateFileType(file) {
    const allowedTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'text/plain',
        'image/jpeg',
        'image/jpg',
        'image/png'
    ];
    
    return allowedTypes.includes(file.type);
}

function validateFiles(files) {
    const maxSize = 10 * 1024 * 1024; // 10MB
    const maxFiles = 20;
    
    if (files.length > maxFiles) {
        showError(`You can upload a maximum of ${maxFiles} files.`);
        return false;
    }
    
    for (let file of files) {
        if (!validateFileType(file)) {
            showError(`File type not allowed: ${file.name}`);
            return false;
        }
        if (file.size > maxSize) {
            showError(`File size exceeds 10MB: ${file.name}`);
            return false;
        }
    }
    return true;
}

function copyToClipboard(text, button) {
    navigator.clipboard.writeText(text).then(() => {
        button.textContent = 'Copied!';
        setTimeout(() => {
            button.innerHTML = '<i class="fas fa-copy"></i> Copy';
        }, 2000);
    }).catch(() => {
        button.textContent = 'Error';
    });
}

function createProgressBar() {
    const progressDiv = document.createElement('div');
    progressDiv.className = 'progress';
    progressDiv.style.cssText = `
        width: 100%;
        background: var(--bg-secondary);
        border-radius: 10px;
        overflow: hidden;
        margin-top: 1rem;
    `;

    const progressBar = document.createElement('div');
    progressBar.className = 'progress-bar';
    progressBar.style.cssText = `
        width: 0%;
        height: 10px;
        background: var(--success-color);
        transition: width 0.3s ease;
    `;

    progressDiv.appendChild(progressBar);

    const mainContainer = document.querySelector('.main-container');
    if (mainContainer) {
        mainContainer.appendChild(progressDiv);
    }

    return { progressDiv, progressBar };
}

function animateProgress(progressBar, duration) {
    let start = null;
    function step(timestamp) {
        if (!start) start = timestamp;
        const progress = (timestamp - start) / duration * 100;
        if (progress < 100) {
            progressBar.style.width = progress + '%';
            requestAnimationFrame(step);
        } else {
            progressBar.style.width = '100%';
        }
    }
    requestAnimationFrame(step);
}

// Example starter JavaScript for disabling form submissions if there are invalid fields
(() => {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  const forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }

      form.classList.add('was-validated')
    }, false)
  })
})()